// ============================================================================
// AI holdings extraction (server-side)
// ----------------------------------------------------------------------------
// Replaces the browser → api.anthropic.com call. Two reasons this must live on
// the server in a bank:
//   1. The model credential is never exposed to the browser.
//   2. Confidentiality: in a regulated deployment, client-identifying data
//      must not leave the perimeter without approved terms. The redact step
//      below strips obvious identifiers before the call; tighten per the
//      bank's data-classification policy (and consider an in-tenant / approved
//      model deployment instead of the public API).
// ============================================================================

const MODEL = process.env.ANTHROPIC_MODEL || "claude-opus-4-5";

// Conservative redaction. Extend to the bank's PII rules. The extractor only
// needs holding lines (name / ticker / value), not client identifiers.
function redact(text) {
  return String(text)
    .replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, "[email]")
    .replace(/\b[A-Z]{2}\d{2}[A-Z0-9]{10,30}\b/g, "[iban]")       // IBAN-like
    .replace(/\b\d{3}\.\d{4}\.\d{4}\.\d{2}\b/g, "[ssn-ch]")        // CH AHV-like
    .slice(0, 6000);
}

const PROMPT = (doc) => `You are a financial data extractor. Below is text from a brokerage/investment document.
Extract every holding as a JSON array item with fields:
- name, tkr, val (number), type (etf|mutual_fund|stock|bond|alternative|precious|other),
  cls (us_equity|intl_equity|fixed_income|real_estate|commodity|cash|alternative),
  region (US|CA|GB|EU|JP|AP|EM|Global), er (decimal or null), yld (decimal or null), note.
Return ONLY a valid JSON array. No markdown, no explanation.

Document text:
${doc}`;

export async function parseHoldings(req, res) {
  const text = req.body?.text;
  if (!text) return res.status(400).json({ error: "missing text" });
  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(503).json({ error: "AI not configured" });
  }
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json"
      },
      body: JSON.stringify({
        model: MODEL, max_tokens: 4096,
        messages: [{ role: "user", content: PROMPT(redact(text)) }]
      })
    });
    if (!r.ok) return res.status(502).json({ error: "AI upstream " + r.status });
    const data = await r.json();
    const content = data.content?.[0]?.text || "[]";
    const m = content.match(/\[[\s\S]*\]/);
    const holdings = m ? JSON.parse(m[0]) : [];
    res.json({ holdings });
  } catch (e) {
    res.status(500).json({ error: "AI parse failed" });
  }
}
