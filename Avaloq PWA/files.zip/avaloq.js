// ============================================================================
// Avaloq Community API client
// ----------------------------------------------------------------------------
// Returns the NORMALIZED contract the front end expects (see wa-mapping.js).
// In mock mode it serves built-in sample data so you can build the whole
// integration before you have portal access. In live mode, fill in the real
// Community API paths + field mappings (marked TODO) — the normalized shape
// you return must stay identical so the front end never changes.
// ============================================================================

const MODE = process.env.AVALOQ_MODE || "mock";

// --- OAuth token cache (client-credentials / on-behalf-of, per your setup) --
let _token = null, _exp = 0;
async function getToken() {
  if (MODE === "mock") return "mock-token";
  if (_token && Date.now() < _exp) return _token;
  // TODO(portal): exchange per Avaloq's documented OAuth flow.
  const res = await fetch(process.env.AVALOQ_TOKEN_URL, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "client_credentials",
      client_id: process.env.AVALOQ_CLIENT_ID,
      client_secret: process.env.AVALOQ_CLIENT_SECRET,
      scope: process.env.AVALOQ_SCOPES || ""
    })
  });
  if (!res.ok) throw new Error("Avaloq token error " + res.status);
  const j = await res.json();
  _token = j.access_token;
  _exp = Date.now() + (j.expires_in || 300) * 1000 - 15000;
  return _token;
}

async function avq(path, advisorCtx) {
  const token = await getToken();
  // TODO(portal): some flows pass the advisor identity (on-behalf-of) so
  // Avaloq enforces that the advisor may only see their own book.
  const res = await fetch(process.env.AVALOQ_API_BASE + path, {
    headers: {
      authorization: "Bearer " + token,
      "x-advisor": advisorCtx?.sub || ""   // shape per your contract
    }
  });
  if (!res.ok) throw new Error("Avaloq " + res.status + " on " + path);
  return res.json();
}

// ---------------------------------------------------------------------------
// MOCK sample data — realistic shapes, CHF, two clients.
// ---------------------------------------------------------------------------
const MOCK = {
  clients: [
    { id: "CLT-1001", displayName: "Müller Family Office", primaryCcy: "CHF", domicile: "CH" },
    { id: "CLT-1002", displayName: "A. Rossi", primaryCcy: "EUR", domicile: "IT" }
  ],
  household: {
    "CLT-1001": { members: [
      { firstName: "Hans", lastName: "Müller", dob: "1968-04-12", role: "primary" },
      { firstName: "Eva",  lastName: "Müller", dob: "1971-09-30", role: "spouse" },
      { firstName: "Lena", lastName: "Müller", dob: "2009-02-18", role: "child" }
    ]},
    "CLT-1002": { members: [{ firstName: "Alessandro", lastName: "Rossi", dob: "1980-11-05", role: "primary" }] }
  },
  portfolios: {
    "CLT-1001": [{ id: "PF-9001", name: "Discretionary Mandate", ccy: "CHF", custodian: "Bank XYZ" }],
    "CLT-1002": [{ id: "PF-9002", name: "Advisory", ccy: "EUR", custodian: "Bank XYZ" }]
  },
  positions: {
    "PF-9001": [
      { instrumentId: "CH0038863350", name: "Nestlé SA", ticker: "NESN", assetClass: "EQUITY", region: "EU", marketValue: 420000, ccy: "CHF", isCash: false, expenseRatio: null, yield: 0.026 },
      { instrumentId: "IE00B4L5Y983", name: "iShares Core MSCI World", ticker: "IWDA", assetClass: "EQUITY_INTL", region: "Global", marketValue: 850000, ccy: "CHF", isCash: false, expenseRatio: 0.002, yield: 0.015 },
      { instrumentId: "CASH-CHF", name: "Cash CHF", ticker: "", assetClass: "CASH", region: "EU", marketValue: 180000, ccy: "CHF", isCash: true }
    ],
    "PF-9002": [
      { instrumentId: "LU0908500753", name: "Lyxor Core Stoxx Europe 600", ticker: "MEUD", assetClass: "EQUITY", region: "EU", marketValue: 220000, ccy: "EUR", isCash: false, expenseRatio: 0.0007, yield: 0.02 }
    ]
  },
  transactions: {
    "PF-9001": [{ id: "TX-1", date: "2026-04-30", type: "BUY", instrumentId: "IE00B4L5Y983", amount: 50000, ccy: "CHF" }]
  },
  instruments: {
    "IE00B4L5Y983": { ticker: "IWDA", name: "iShares Core MSCI World", assetClass: "EQUITY_INTL", region: "Global", expenseRatio: 0.002, yield: 0.015 }
  }
};

// ---------------------------------------------------------------------------
// Public methods → normalized contract.
// ---------------------------------------------------------------------------
export async function getClients(ctx) {
  if (MODE === "mock") return { clients: MOCK.clients };
  const raw = await avq("/clients", ctx);                       // TODO(portal): real path
  return { clients: raw.items.map(x => ({                        // TODO(portal): field names
    id: x.clientId, displayName: x.name, primaryCcy: x.referenceCurrency, domicile: x.domicile
  })) };
}

export async function getHousehold(clientId, ctx) {
  if (MODE === "mock") return MOCK.household[clientId] || { members: [] };
  const raw = await avq(`/clients/${encodeURIComponent(clientId)}/related-persons`, ctx); // TODO
  return { members: raw.items.map(p => ({
    firstName: p.givenName, lastName: p.familyName, dob: p.birthDate, role: p.relationship
  })) };
}

export async function getPortfolios(clientId, ctx) {
  if (MODE === "mock") return { portfolios: MOCK.portfolios[clientId] || [] };
  const raw = await avq(`/clients/${encodeURIComponent(clientId)}/portfolios`, ctx); // TODO
  return { portfolios: raw.items.map(p => ({
    id: p.portfolioId, name: p.name, ccy: p.currency, custodian: p.custodian
  })) };
}

export async function getPositions(clientId, portfolioId, ctx) {
  if (MODE === "mock") {
    const pf = portfolioId || (MOCK.portfolios[clientId]?.[0]?.id);
    const domicile = MOCK.clients.find(c => c.id === clientId)?.domicile || "CH";
    const ccy = MOCK.portfolios[clientId]?.[0]?.ccy || "CHF";
    return { positions: MOCK.positions[pf] || [], domicile, ccy };
  }
  const pf = portfolioId; // resolve default on the backend if absent
  const raw = await avq(`/portfolios/${encodeURIComponent(pf)}/positions`, ctx); // TODO
  return { positions: raw.items.map(p => ({                       // TODO(portal): field names
    instrumentId: p.instrumentId, name: p.instrumentName, ticker: p.symbol,
    assetClass: p.assetClass, region: p.region, marketValue: p.valuationCcyRef,
    ccy: p.currency, isCash: p.instrumentType === "CASH",
    expenseRatio: p.ter ?? null, yield: p.yield ?? null
  })) };
}

export async function getTransactions(clientId, portfolioId, ctx) {
  if (MODE === "mock") return { transactions: MOCK.transactions[portfolioId] || [] };
  const raw = await avq(`/portfolios/${encodeURIComponent(portfolioId)}/transactions`, ctx); // TODO
  return { transactions: raw.items.map(t => ({
    id: t.id, date: t.bookingDate, type: t.type, instrumentId: t.instrumentId,
    amount: t.amount, ccy: t.currency
  })) };
}

export async function getInstrument(instrumentId, ctx) {
  if (MODE === "mock") return MOCK.instruments[instrumentId] || null;
  const raw = await avq(`/instruments/${encodeURIComponent(instrumentId)}`, ctx); // TODO
  return { ticker: raw.symbol, name: raw.name, assetClass: raw.assetClass,
           region: raw.region, expenseRatio: raw.ter ?? null, yield: raw.yield ?? null };
}
