// ============================================================================
// Market data broker
// ----------------------------------------------------------------------------
// Replaces the front end's ~20 direct API calls + the public corsproxy.io
// fallback. Two responsibilities:
//   1. Hold market-data API keys server-side (never in the browser).
//   2. Expose a NARROW, allowlisted proxy — NOT an open proxy. An open
//      "?url=" proxy is an SSRF hole; we only forward to known hosts.
// In production, prefer the bank's own licensed feed over retail APIs.
// ============================================================================

// Hosts the front end is permitted to reach THROUGH the backend. Trim this to
// only what you actually use; the smaller the better for security review.
const ALLOWED_HOSTS = new Set([
  "finnhub.io",
  "api.twelvedata.com",
  "api.polygon.io",
  "www.alphavantage.co",
  "api.frankfurter.app",
  "api.coingecko.com",
  "api.stlouisfed.org"
]);

export async function proxy(req, res) {
  const target = req.query.url;
  if (!target) return res.status(400).json({ error: "missing url" });
  let u;
  try { u = new URL(target); } catch { return res.status(400).json({ error: "bad url" }); }
  if (u.protocol !== "https:") return res.status(400).json({ error: "https only" });
  if (!ALLOWED_HOSTS.has(u.hostname)) {
    return res.status(403).json({ error: "host not allowlisted: " + u.hostname });
  }
  try {
    // Inject server-side key if the provider needs one (example: Finnhub).
    if (u.hostname === "finnhub.io" && process.env.MARKETDATA_API_KEY) {
      u.searchParams.set("token", process.env.MARKETDATA_API_KEY);
    }
    const r = await fetch(u.toString(), { headers: { accept: "application/json" } });
    const body = await r.text();
    res.status(r.status).type("application/json").send(body);
  } catch (e) {
    res.status(502).json({ error: "upstream fetch failed" });
  }
}
