// ============================================================================
// Wealth Analyzer — Avaloq adapter backend (broker)
// ----------------------------------------------------------------------------
// The single trusted server between the advisor's browser and the bank's
// systems. Holds all secrets; the browser holds only a session cookie.
//
//   browser  ──cookie──►  THIS backend  ──OAuth──►  Avaloq Community API
//                                       ──key────►  market data / AI
//
// Run:  cp .env.example .env  &&  npm install  &&  npm start
// Dev login:  POST /auth/login  (synthesises an advisor session in non-prod)
// ============================================================================

import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import cookieSession from "cookie-session";

import * as avaloq from "./avaloq.js";
import * as market from "./marketdata.js";
import * as ai from "./ai.js";
import { requireAuth, login, callback, logout } from "./auth.js";

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", 1);

// --- Security ---------------------------------------------------------------
app.use(helmet());
app.use(express.json({ limit: "256kb" }));

// CORS locked to the exact front-end origin; credentials allowed for cookie.
const ORIGIN = process.env.FRONTEND_ORIGIN || "http://localhost:5173";
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", ORIGIN);
  res.header("Access-Control-Allow-Credentials", "true");
  res.header("Access-Control-Allow-Headers", "content-type");
  res.header("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

// Signed, http-only session cookie. Secure + SameSite in production.
app.use(cookieSession({
  name: "wa_sess",
  secret: process.env.SESSION_SECRET || "dev-secret",
  httpOnly: true,
  sameSite: "lax",
  secure: process.env.NODE_ENV === "production",
  maxAge: 8 * 60 * 60 * 1000
}));

app.use(rateLimit({ windowMs: 60_000, max: 120 }));

// IMPORTANT: do not log full URLs / query strings / bodies — they may carry
// client identifiers. Log method + path + status only.
app.use((req, res, next) => {
  res.on("finish", () => console.log(req.method, req.path, res.statusCode));
  next();
});

// --- Auth -------------------------------------------------------------------
app.post("/auth/login", login);
app.get("/auth/callback", callback);
app.post("/auth/logout", logout);
app.get("/auth/me", (req, res) => res.json({ advisor: req.session?.advisor || null }));

// --- Avaloq (all require an authenticated advisor) --------------------------
const ctx = (req) => req.session.advisor;
app.get("/api/avaloq/clients", requireAuth, async (req, res, next) => {
  try { res.json(await avaloq.getClients(ctx(req))); } catch (e) { next(e); }
});
app.get("/api/avaloq/clients/:id/household", requireAuth, async (req, res, next) => {
  try { res.json(await avaloq.getHousehold(req.params.id, ctx(req))); } catch (e) { next(e); }
});
app.get("/api/avaloq/clients/:id/portfolios", requireAuth, async (req, res, next) => {
  try { res.json(await avaloq.getPortfolios(req.params.id, ctx(req))); } catch (e) { next(e); }
});
app.get("/api/avaloq/clients/:id/positions", requireAuth, async (req, res, next) => {
  try { res.json(await avaloq.getPositions(req.params.id, req.query.portfolioId, ctx(req))); }
  catch (e) { next(e); }
});
app.get("/api/avaloq/clients/:id/transactions", requireAuth, async (req, res, next) => {
  try { res.json(await avaloq.getTransactions(req.params.id, req.query.portfolioId, ctx(req))); }
  catch (e) { next(e); }
});
app.get("/api/avaloq/instruments/:id", requireAuth, async (req, res, next) => {
  try { res.json(await avaloq.getInstrument(req.params.id, ctx(req))); } catch (e) { next(e); }
});

// --- Market data + AI -------------------------------------------------------
app.get("/api/marketdata/proxy", requireAuth, market.proxy);
app.post("/api/ai/parse-holdings", requireAuth, ai.parseHoldings);

// --- Health + error handler -------------------------------------------------
app.get("/healthz", (req, res) => res.json({ ok: true, mode: process.env.AVALOQ_MODE || "mock" }));
app.use((err, req, res, _next) => {
  console.error("ERR", req.method, req.path, err.message);
  res.status(500).json({ error: "internal_error" }); // never leak internals
});

const PORT = process.env.PORT || 8443;
app.listen(PORT, () => {
  console.log(`Avaloq adapter backend on :${PORT}  mode=${process.env.AVALOQ_MODE || "mock"}`);
});
