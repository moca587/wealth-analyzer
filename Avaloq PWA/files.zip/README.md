# Wealth Analyzer — Avaloq Certified-Adapter Integration

This turns the standalone Wealth Analyzer into an Avaloq.one **certified adapter**:
a standalone advisor web app that reads an advisor's clients and portfolios from
the bank's Avaloq Banking Suite, runs your existing planning engine on that data,
and renders it in your existing UI.

The planning engine and UI are unchanged. What changed is **where data comes from**
and **where secrets and state live**.

## Architecture

```
   Advisor browser                Your backend (broker)            Bank systems
 ┌───────────────────┐   cookie  ┌──────────────────────┐  OAuth ┌──────────────┐
 │ wealth-analyzer    │ ───────► │ /api/avaloq/*         │ ─────► │ Avaloq        │
 │  + engine + UI     │          │ /api/marketdata/proxy │  key   │ Community API │
 │  + provider layer  │ ◄─────── │ /api/ai/parse-holdings│ ─────► │ market / AI   │
 └───────────────────┘  JSON    └──────────────────────┘        └──────────────┘
   holds: session cookie only      holds: ALL secrets
```

The browser never holds an Avaloq credential, market-data key, or model key, and
in Avaloq mode never writes client data to `localStorage`.

## Two modes

- **Demo / standalone** (default): leave `WA_CONFIG` unset. Behaves exactly as
  before — manual entry, PDF import, public market APIs, browser-side demo AI.
- **Avaloq mode**: set `window.WA_CONFIG = { backendBase: "https://adapter.yourbank.ch" }`.
  All data, market, and AI traffic routes through the backend; the public CORS
  proxy and browser-side model key are disabled automatically.

## File map

```
frontend/
  wealth-analyzer.html     your app + 4 surgical edits (see below)
  wa-mapping.js            Avaloq normalized JSON → engine object shapes
  wa-provider-layer.js     LocalProvider | AvaloqProvider + WA.loadClient()
backend/
  src/server.js            Express broker: security, session, routes
  src/auth.js              advisor OIDC SSO (dev-login stub included)
  src/avaloq.js            Community API client + mock data + normalized contract
  src/marketdata.js        server-side market data + allowlisted (SSRF-safe) proxy
  src/ai.js                server-side holdings extraction + PII redaction
  .env.example             every secret, documented
docs/
  README.md  NEXT-STEPS.md
```

## What changed inside wealth-analyzer.html (4 edits)

1. **Engine bridge** after the array declarations — publishes in-scope
   setters (`window.__WA_ENGINE__`) so the provider can write Avaloq data into
   the engine's own `assets` / `investments` / `children` arrays.
2. **`parseHoldingsWithClaude`** — in Avaloq mode routes to `/api/ai/parse-holdings`
   instead of calling `api.anthropic.com` from the browser.
3. **`corsFetch`** — in Avaloq mode routes market data through the backend and
   **disables the corsproxy.io fallback** (disqualifying in a bank).
4. **Module includes** before `</body>** (config → mapping → provider).

Demo behaviour is untouched when `WA_CONFIG` is unset.

## Run the backend (mock mode — no Avaloq access needed yet)

```bash
cd backend
cp .env.example .env          # AVALOQ_MODE=mock by default
npm install
node --env-file=.env src/server.js     # Node 20.6+; or `npm start`
```

Smoke test:

```bash
curl -c cj -X POST localhost:8443/auth/login           # dev advisor session
curl -b cj localhost:8443/api/avaloq/clients            # normalized clients
curl -b cj localhost:8443/api/avaloq/clients/CLT-1001/positions
```

## Point the front end at the backend

Serve `frontend/` and set the config (in the page or via your deploy):

```js
window.WA_CONFIG = { backendBase: "http://localhost:8443" };
```

Then `await WA.loadClient("CLT-1001")` loads that client's household + positions
into the engine and refreshes the UI. Wire this to a client-picker built from
`await WA.provider.getClients()`.

## Going live (replacing mock)

In `backend/src/avaloq.js`, every method has the normalized output it must return.
Set `AVALOQ_MODE=live` and fill in the real Community API paths + field names at
the `TODO(portal)` markers. The front end does not change — only the backend's
field mapping does.
