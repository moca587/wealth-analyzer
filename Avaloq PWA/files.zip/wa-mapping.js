/* ============================================================================
 * Wealth Analyzer — Avaloq → Engine mapping
 * ----------------------------------------------------------------------------
 * Translates the BACKEND's normalized JSON into the EXACT object shapes the
 * planning engine already uses, then writes them into the engine's arrays via
 * window.__WA_ENGINE__ (the in-scope bridge injected into the app).
 *
 * Engine shapes (discovered from the app, do not change these):
 *   asset:       {id,type,group,label,baseLabel,value,liquid,country,note,ccy,withdrawAge}
 *   investment:  {id,name,tkr,type,cls,region,val,er,yld,note}
 *   child:       {id,first,last,dob}
 *
 * The backend returns a STABLE normalized contract (below). When you get
 * Avaloq portal access, you map Community-API field names → this contract on
 * the backend; this file never has to change.
 *
 * Backend normalized contract:
 *   client:     {id, displayName, primaryCcy, domicile}
 *   member:     {firstName, lastName, dob, role}
 *   portfolio:  {id, name, ccy, custodian}
 *   position:   {instrumentId, name, ticker, assetClass, region, marketValue,
 *                ccy, isCash, accountType, expenseRatio, yield}
 *   transaction:{id, date, type, instrumentId, amount, ccy}
 *   instrument: {ticker, name, assetClass, region, expenseRatio, yield}
 * ==========================================================================*/
(function (global) {
  "use strict";
  const WA = global.WA || {};

  // Avaloq asset-class codes → engine `cls` enum. Extend once you see real codes.
  const CLASS_MAP = {
    EQUITY: "us_equity", EQUITY_INTL: "intl_equity", BOND: "fixed_income",
    FIXED_INCOME: "fixed_income", REAL_ESTATE: "real_estate",
    COMMODITY: "commodity", CASH: "cash", ALTERNATIVE: "alternative"
  };
  // Map a cash/deposit position to the engine's bank-account asset type.
  const CASH_ASSET = { type: "checking", group: "cash", liquid: true };

  let _seq = 0;
  const nextId = (p) => p + "_avq_" + (++_seq);

  function mapClass(c) { return CLASS_MAP[(c || "").toUpperCase()] || "us_equity"; }
  function clean(n) { const x = parseFloat(n); return isNaN(x) ? 0 : x; }

  const mapping = {
    client(c) {
      return { id: c.id, name: c.displayName || c.id, ccy: c.primaryCcy || "CHF", domicile: c.domicile || "" };
    },
    portfolio(p) {
      return { id: p.id, name: p.name || p.id, ccy: p.ccy || "CHF", custodian: p.custodian || "" };
    },
    household(raw) {
      const members = (raw.members || []).map(m => ({
        first: m.firstName || "", last: m.lastName || "", dob: m.dob || "", role: m.role || "member"
      }));
      const children = (raw.members || [])
        .filter(m => (m.role || "").toLowerCase() === "child")
        .map(m => ({ id: nextId("ch"), first: m.firstName || "", last: m.lastName || "", dob: m.dob || "" }));
      return { members, children };
    },
    transaction(t) {
      return { id: t.id, date: t.date, type: t.type, instrumentId: t.instrumentId, amount: clean(t.amount), ccy: t.ccy };
    },
    instrument(i) {
      if (!i) return null;
      return {
        tkr: i.ticker || "", name: i.name || "", cls: mapClass(i.assetClass),
        region: i.region || "Global",
        er: i.expenseRatio != null ? clean(i.expenseRatio) : null,
        yld: i.yield != null ? clean(i.yield) : null
      };
    },
    // The important one: a portfolio's positions → {assets, investments}.
    // Cash/deposit lines become "assets" (bank accounts); securities become
    // "investments" (the holdings the portfolio engine analyzes).
    positions(raw) {
      const assets = [], investments = [];
      (raw.positions || []).forEach(p => {
        const mv = clean(p.marketValue);
        if (mv <= 0) return;
        if (p.isCash || (p.assetClass || "").toUpperCase() === "CASH") {
          assets.push({
            id: nextId("a"), type: CASH_ASSET.type, group: CASH_ASSET.group,
            label: p.name || "Cash account", baseLabel: "Cash",
            value: mv, liquid: true, country: raw.domicile || "CH",
            note: "From Avaloq portfolio", ccy: p.ccy || raw.ccy || "CHF", withdrawAge: null
          });
        } else {
          investments.push({
            id: nextId("inv"), name: p.name || "Holding", tkr: p.ticker || "",
            type: "stock", cls: mapClass(p.assetClass), region: p.region || "Global",
            val: mv, er: p.expenseRatio != null ? clean(p.expenseRatio) : null,
            yld: p.yield != null ? clean(p.yield) : null, note: "From Avaloq"
          });
        }
      });
      return { assets, investments };
    },

    // Write mapped data into the live engine arrays via the in-scope bridge.
    applyToEngine({ household, positions }) {
      const E = global.__WA_ENGINE__;
      if (!E) { console.warn("[WA] engine bridge missing — load client skipped"); return; }
      if (positions) {
        E.setAssets(positions.assets || []);
        E.setInvestments(positions.investments || []);
      }
      if (household && household.children) E.setChildren(household.children);
      E.refresh();
    }
  };

  WA.mapping = mapping;
  global.WA = WA;
})(window);
