/* ============================================================================
 * Wealth Analyzer — Data Provider Layer
 * ----------------------------------------------------------------------------
 * Decouples the planning engine + UI from WHERE portfolio data comes from.
 *
 *   LocalProvider   → current behaviour (manual entry / PDF import / demo).
 *                     Nothing changes for standalone/demo use.
 *   AvaloqProvider  → reads the advisor's clients & portfolios from the bank's
 *                     Avaloq Banking Suite, brokered through YOUR backend
 *                     (never the browser → Avaloq directly).
 *
 * The engine only ever talks to `WA.provider`. Swapping the source is one line.
 *
 * IMPORTANT (regulated-banking constraints baked in here):
 *   - The browser NEVER holds Avaloq credentials or calls Avaloq directly.
 *   - All Avaloq/market/AI traffic goes through WA_CONFIG.backendBase.
 *   - No client data is written to localStorage in Avaloq mode.
 * ==========================================================================*/
(function (global) {
  "use strict";

  // --- Runtime config ------------------------------------------------------
  // backendBase === "" → demo/standalone mode (LocalProvider).
  // Set it (e.g. "https://adapter.yourco.ch") to activate AvaloqProvider.
  const WA_CONFIG = global.WA_CONFIG || {
    backendBase: "",          // your broker backend origin
    mode: "local",            // "local" | "avaloq"
    persistClientData: true   // forced to false in avaloq mode below
  };
  if (WA_CONFIG.backendBase) { WA_CONFIG.mode = "avaloq"; WA_CONFIG.persistClientData = false; }

  // --- Helper: authenticated fetch to the backend --------------------------
  // The backend owns the Avaloq/OAuth token exchange. The browser sends its
  // own short-lived session cookie/bearer (set at advisor login via OIDC).
  async function apiFetch(path, opts) {
    opts = opts || {};
    const headers = Object.assign(
      { "content-type": "application/json" },
      opts.headers || {}
    );
    const res = await fetch(WA_CONFIG.backendBase + path, {
      method: opts.method || "GET",
      headers,
      credentials: "include",          // send session cookie to backend only
      body: opts.body ? JSON.stringify(opts.body) : undefined
    });
    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      throw new Error("Backend " + res.status + " on " + path + " — " + txt);
    }
    return res.json();
  }

  /* ==========================================================================
   * The provider contract. Both providers implement exactly this surface.
   * Return shapes match what the engine already consumes (see wa-mapping).
   * ========================================================================*/
  const ProviderContract = [
    "getClients",        // ()                → [{id, name, ...}]
    "getHousehold",      // (clientId)        → {members:[...], children:[...]}
    "getPortfolios",     // (clientId)        → [{id, name, ccy, custodian}]
    "getPositions",      // (clientId, pfId?) → {assets:[...], investments:[...]}
    "getTransactions",   // (clientId, pfId?) → [...]
    "getInstrument",     // (instrumentId)    → {tkr, name, cls, region, er, yld}
    "parseHoldingsDoc"   // (text)            → [investment,...]  (AI extract)
  ];

  /* ------------------------------------------------------------------------
   * LocalProvider — preserves today's behaviour.
   * Avaloq feed methods resolve empty; the UI keeps manual entry + PDF import.
   * parseHoldingsDoc defers to the app's existing in-page Claude function if
   * one is present (kept ONLY for demo mode — disabled in avaloq mode).
   * ----------------------------------------------------------------------*/
  const LocalProvider = {
    name: "local",
    async getClients() { return []; },            // advisor book lives in Avaloq only
    async getHousehold() { return { members: [], children: [] }; },
    async getPortfolios() { return []; },
    async getPositions() { return { assets: [], investments: [] }; },
    async getTransactions() { return []; },
    async getInstrument() { return null; },
    async parseHoldingsDoc(text) {
      // Demo-only: use the page's existing browser-side extractor if available.
      if (typeof global.parseHoldingsWithClaude === "function") {
        const key = typeof global.getClaudeKey === "function" ? global.getClaudeKey() : "";
        if (!key) throw new Error("No demo API key set");
        return global.parseHoldingsWithClaude(text, key);
      }
      throw new Error("Document parsing not available in this mode");
    }
  };

  /* ------------------------------------------------------------------------
   * AvaloqProvider — reads from the bank via the backend broker.
   * Each method maps the backend's normalized JSON onto the engine's shapes
   * using WA.mapping (see wa-mapping.js). The exact Avaloq Community API
   * field names are filled in on the BACKEND once you have portal access —
   * the front end stays stable regardless of those names.
   * ----------------------------------------------------------------------*/
  const AvaloqProvider = {
    name: "avaloq",
    async getClients() {
      const raw = await apiFetch("/api/avaloq/clients");
      return (raw.clients || []).map(WA.mapping.client);
    },
    async getHousehold(clientId) {
      const raw = await apiFetch("/api/avaloq/clients/" + encodeURIComponent(clientId) + "/household");
      return WA.mapping.household(raw);
    },
    async getPortfolios(clientId) {
      const raw = await apiFetch("/api/avaloq/clients/" + encodeURIComponent(clientId) + "/portfolios");
      return (raw.portfolios || []).map(WA.mapping.portfolio);
    },
    async getPositions(clientId, pfId) {
      const q = pfId ? ("?portfolioId=" + encodeURIComponent(pfId)) : "";
      const raw = await apiFetch("/api/avaloq/clients/" + encodeURIComponent(clientId) + "/positions" + q);
      return WA.mapping.positions(raw);  // → {assets, investments}
    },
    async getTransactions(clientId, pfId) {
      const q = pfId ? ("?portfolioId=" + encodeURIComponent(pfId)) : "";
      const raw = await apiFetch("/api/avaloq/clients/" + encodeURIComponent(clientId) + "/transactions" + q);
      return (raw.transactions || []).map(WA.mapping.transaction);
    },
    async getInstrument(instrumentId) {
      const raw = await apiFetch("/api/avaloq/instruments/" + encodeURIComponent(instrumentId));
      return WA.mapping.instrument(raw);
    },
    async parseHoldingsDoc(text) {
      // Server-side AI: client data never leaves the bank perimeter from the browser.
      const raw = await apiFetch("/api/ai/parse-holdings", { method: "POST", body: { text } });
      return raw.holdings || [];
    }
  };

  // --- Public surface ------------------------------------------------------
  const WA = global.WA || {};
  WA.config = WA_CONFIG;
  WA.ProviderContract = ProviderContract;
  WA.LocalProvider = LocalProvider;
  WA.AvaloqProvider = AvaloqProvider;
  WA.provider = WA_CONFIG.mode === "avaloq" ? AvaloqProvider : LocalProvider;

  // Convenience: load a client's full picture into the app's arrays.
  // Wires Avaloq data into the SAME module-level arrays the engine reads
  // (assets / investments / children). Call this from a "Load client" button.
  WA.loadClient = async function (clientId, opts) {
    if (WA.provider.name !== "avaloq") throw new Error("loadClient requires Avaloq mode");
    opts = opts || {};
    const [household, positions] = await Promise.all([
      WA.provider.getHousehold(clientId),
      WA.provider.getPositions(clientId, opts.portfolioId)
    ]);
    // The mapping module exposes setters that target the engine's arrays
    // without the engine needing to know data came from Avaloq.
    WA.mapping.applyToEngine({ household, positions });
    if (typeof global.recompute === "function") global.recompute();
    return { household, positions };
  };

  global.WA = WA;
  global.WA_CONFIG = WA_CONFIG;
  console.info("[WA] Provider layer active —", WA.provider.name, "mode");
})(window);
