// ============================================================================
// Advisor authentication (OIDC against the bank's IdP)
// ----------------------------------------------------------------------------
// Real flow: redirect to the bank IdP, handle the callback, verify the ID
// token, store a minimal advisor identity in the session. The browser only
// ever holds the session cookie — never an Avaloq or model credential.
//
// This stub gives you a working dev login now; wire the real OIDC handshake
// (e.g. with `openid-client`) where marked TODO once you have IdP details.
// ============================================================================

export function requireAuth(req, res, next) {
  if (req.session && req.session.advisor) return next();
  return res.status(401).json({ error: "not authenticated" });
}

export function login(req, res) {
  if (process.env.NODE_ENV !== "production") {
    // DEV ONLY: synthesise an advisor session so you can build against mock data.
    req.session.advisor = { sub: "advisor-dev", name: "Dev Advisor" };
    return res.json({ ok: true, advisor: req.session.advisor });
  }
  // TODO(IdP): build the authorization URL and redirect.
  // const url = client.authorizationUrl({ scope: "openid profile", ... });
  // return res.redirect(url);
  return res.status(501).json({ error: "OIDC not configured" });
}

export async function callback(req, res) {
  // TODO(IdP): exchange code, verify ID token, then:
  // req.session.advisor = { sub: claims.sub, name: claims.name };
  return res.status(501).json({ error: "OIDC callback not configured" });
}

export function logout(req, res) {
  req.session = null;
  res.json({ ok: true });
}
