# Next steps — to a certified Avaloq adapter

Ordered by dependency. Items 1–3 you can do now; they don't need portal access.

## 1. Build the advisor experience on the provider (now)
- Add a client picker: `await WA.provider.getClients()` → list → `WA.loadClient(id)`.
- Add a portfolio selector per client (`getPortfolios`) when a client has more
  than one mandate.
- Decide which planning inputs stay advisor-entered (goals, expenses, income
  assumptions) vs. sourced from Avaloq (balance sheet / positions). Persist the
  advisor-entered ones in your backend keyed to the Avaloq client id — not in
  `localStorage`.

## 2. Harden the backend (now)
- Replace the dev login in `auth.js` with the real OIDC handshake against the
  bank's IdP (e.g. `openid-client`). Verify the ID token; store only a minimal
  advisor identity in the session.
- Persistence: move any durable state to a datastore in an approved Swiss region.
- Secrets: load from the bank's secret manager, not `.env`, in production.
- Tighten `marketdata.js` ALLOWED_HOSTS to only what you actually call; prefer
  the bank's licensed feed over retail APIs.
- Refine `CLASS_MAP` in `wa-mapping.js` once you see real Avaloq asset-class
  codes (current mapping is a placeholder; use assetClass + region together).
- Tighten the PII redaction in `ai.js` to the bank's data-classification policy,
  and confirm whether the AI feature is allowed at all / needs an in-tenant or
  approved model deployment.

## 3. Stand up infrastructure (now)
- Host the backend in an approved region (Swiss region in practice for FINMA
  data-residency expectations).
- TLS everywhere; secure + SameSite cookies; CSP on the front end.
- Plan for the bank's own security review and penetration test on top of
  Avaloq's certification — build to that bar from the start.

## 4. Onboard to Avaloq (gated)
- Register on `developer.avaloq.com`; request access to the Community APIs.
- Use the AWS-hosted sandbox "model bank" to develop against real API shapes.
- Fill in the `TODO(portal)` field mappings in `avaloq.js`; set `AVALOQ_MODE=live`.
- Confirm the auth model (client-credentials vs on-behalf-of) so an advisor only
  ever sees their own book.

## 5. Certify and list
- Submit for technical certification as a **certified adapter** (third-party
  built, Avaloq-validated).
- Complete partner onboarding; list on Avaloq.one so any Avaloq bank can enable it.

## Open questions to resolve early
- **AI feature**: is sending (even redacted) holding text to an external model
  acceptable to target banks, or does it need an approved/in-tenant deployment?
  This shapes the whole `/api/ai` path.
- **Market data**: licensed bank feed vs. your own provider contract — affects
  both cost and what `ALLOWED_HOSTS` needs to contain.
- **Write-back**: this design is read-only from Avaloq. If you ever need to push
  data back (e.g. proposals), that's a separate, higher-scrutiny API surface.

## What's proven working in this scaffold
- Backend mock mode: auth gate, advisor session, normalized clients / household /
  portfolios / positions / transactions / instruments, SSRF-safe market proxy.
- Front-end mapping: backend positions/household → exact engine `assets` /
  `investments` / `children` shapes, written via the in-scope bridge.
- Demo mode unchanged when `WA_CONFIG` is unset.
